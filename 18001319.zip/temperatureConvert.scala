object TemperatureConverter { 
      
   def main(args: Array[String]) { 
      println("F is: " + celciusToFahrenheit(35.00)); 
   } 
     
   def celciusToFahrenheit(c:Double) : Double = 
   { 
         
       var f:Double = 0.0
       f = c*1.8 + 32.00 
  
       // f is the value of Fahrenheit
       return f 
   } 
}