import scala.math.pow

object VolumeCalculator { 
      
   def main(args: Array[String]) { 
      println("Volume is: " + volumeSphere(5)); 
   } 
   def volumeSphere(r:Double) : Double = 
   { 
         
       var v:Double = 0.0
       var pi:Double = 3.14
       v = 4.0/3.0 * 3.14 * pow(r,3)
  
       // v is the volume
       return v 
   } 
}