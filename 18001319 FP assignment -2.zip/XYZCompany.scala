// In this program we calculate salary for a WEEK

object XYZ{
  def main(args: Array[String])={
    printf("Salary with tax : "+takeHome(40,20))
  }
  def wage(hours:Int):Int=hours*150
  def ot(hours:Int):Int=hours*75
  def income(wage:Int,ot:Int):Int=wage+ot
  def tax(income:Int):Double=income*0.1

  def takeHome(wageHours:Int,otHours:Int):Double={
    var salary=income(wage(wageHours),ot(otHours))-tax(income(wage(wageHours),ot(otHours)))
    return salary
  }
}



