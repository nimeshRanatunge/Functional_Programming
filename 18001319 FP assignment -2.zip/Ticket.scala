object Ticket {
  def main(args: Array[String]): Unit = {
    println("Profit for Rs10\t"+profit(10))
    println("Profit for Rs15\t"+profit(15))
    println("Profit for Rs20\t"+profit(20))
  }
  def attendees(price:Int):Int=(120+(15-price)/5*20)
  def revenue(price:Int):Int=attendees(price)*price
  def cost(price:Int):Int=500+attendees(price)*3
  def profit(price:Int):Int=revenue(price)-cost(price)
}