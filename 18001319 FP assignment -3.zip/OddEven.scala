object OddEven 
{ 
def main(args:Array[String]) 
    { 
      if(oddEven(16)){
        println("Even") 
      }else{
        println("Odd")
      }
    }   

    def oddEven(num: Int): Boolean=
    { 
        if (num%2 == 0) 
            return true
        else
            return false 
    } 
} 